<div>
<div class="signup-form">
<h2>Register your account</h2>
<form id="register_form" ">
	<input type="text" name="username" placeholder="Name" /><br>
	<input type="text" name="usermobile" placeholder="Mobile No."/><br>
	<input type="email" name="useremail" placeholder="Enter User Email Address" /><br>
	<input type="password" name="userpassword" placeholder="Enter User Password"/><br>
	<input type="password" name="cpassword" placeholder="Enter User CPassword"/><br>
	<button type="button" class="btn-register">Register</button>
</form>
<div class="msg_register"></div>
</div>
</div>