<?php
	$conn = new mysqli("localhost","root","","pinank");
		
?>