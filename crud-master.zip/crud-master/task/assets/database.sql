create table record(
	id int auto_increment primary key,
	first text,
	last text
);