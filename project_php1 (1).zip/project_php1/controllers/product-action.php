<?php
  require_once '../models/db_project.php';
  pre($_POST);
  pre($_FILES);
?>